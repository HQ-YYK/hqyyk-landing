#!/usr/bin/env bash
# 续费提醒（卡片版）：每天查小兔云面板，剩余天数 ≤ 3 天时发飞书卡片（进入阈值后每天发一次，直到续费）
# 部署时占位符会被换成真实值（不进任何文件与汇报）
FEISHU_WEBHOOK="__FEISHU_WEBHOOK__"
PANEL_EMAIL="__PANEL_EMAIL__"
PANEL_PASSWORD="__PANEL_PASSWORD__"
API_BASE="https://vps.xiaotucloud.top/api"
THRESHOLD_DAYS=3
CHECK_INTERVAL=86400

# JSON 转义（无 python3，用 sed）
json_escape() {
  printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' -e ':a;N;$!ba;s/\n/\\n/g'
}

# 指标块：metric_block <标签1> <值1> [标签2] [值2]（浅灰底 column_set，大数字 + 小灰字）
metric_block() {
  local l1="$1" v1="$2" l2="${3:-}" v2="${4:-}"
  local c1 c2 cols
  c1="{\"tag\":\"column\",\"width\":\"weighted\",\"weight\":1,\"background_style\":\"grey-50\",\"elements\":[{\"tag\":\"markdown\",\"text_size\":\"notation\",\"content\":\"<font color='grey'>$(json_escape "$l1")</font>\"},{\"tag\":\"markdown\",\"text_size\":\"heading\",\"content\":\"**$(json_escape "$v1")**\"}]}"
  cols="$c1"
  if [ -n "$l2" ]; then
    c2="{\"tag\":\"column\",\"width\":\"weighted\",\"weight\":1,\"background_style\":\"grey-50\",\"elements\":[{\"tag\":\"markdown\",\"text_size\":\"notation\",\"content\":\"<font color='grey'>$(json_escape "$l2")</font>\"},{\"tag\":\"markdown\",\"text_size\":\"heading\",\"content\":\"**$(json_escape "$v2")**\"}]}"
    cols="$c1,$c2"
  fi
  printf '{"tag":"column_set","background_style":"grey-50","flex_mode":"stretch","columns":[%s]}' "$cols"
}

# 发飞书卡片（Card JSON 2.0；2.0 不支持 note 标签，底部备注用灰色 markdown）
# send_card <template> <标题> <副标题> <正文markdown> <底部备注> [状态标签] [指标块JSON]
send_card() {
  local template="$1" title="$2" subtitle="$3" body="$4" note="$5" tag="${6:-}" metric="${7:-}"
  local t s b n resp tag_json="" metric_json=""
  case "$template" in
    blue|green|red|orange|purple) ;;
    *) template="blue" ;;
  esac
  t="$(json_escape "$title")"
  s="$(json_escape "$subtitle")"
  b="$(json_escape "$body")"
  n="$(json_escape "$note")"
  if [ -n "$tag" ]; then
    tag_json=",\"text_tag_list\":[{\"tag\":\"text_tag\",\"text\":{\"tag\":\"plain_text\",\"content\":\"$(json_escape "$tag")\"},\"color\":\"$template\"}]"
  fi
  if [ -n "$metric" ]; then
    metric_json=",${metric}"
  fi
  resp="$(curl -s --connect-timeout 15 --max-time 30 -X POST "$FEISHU_WEBHOOK" -H "Content-Type: application/json" -d "{\"msg_type\":\"interactive\",\"card\":{\"schema\":\"2.0\",\"header\":{\"template\":\"$template\",\"title\":{\"tag\":\"plain_text\",\"content\":\"$t\"},\"subtitle\":{\"tag\":\"plain_text\",\"content\":\"$s\"}$tag_json},\"body\":{\"vertical_spacing\":\"16px\",\"padding\":\"16px 20px\",\"elements\":[{\"tag\":\"markdown\",\"content\":\"$b\"}$metric_json,{\"tag\":\"hr\"},{\"tag\":\"markdown\",\"text_size\":\"notation\",\"content\":\"<font color='grey'>$n</font>\"}]}}}" 2>/dev/null)"
  if printf '%s' "$resp" | grep -q '"code": *0'; then
    return 0
  fi
  # 新版卡片失败，兜底极简卡（去掉指标块与容器间距）
  resp="$(curl -s --connect-timeout 15 --max-time 30 -X POST "$FEISHU_WEBHOOK" -H "Content-Type: application/json" -d "{\"msg_type\":\"interactive\",\"card\":{\"schema\":\"2.0\",\"header\":{\"template\":\"$template\",\"title\":{\"tag\":\"plain_text\",\"content\":\"$t\"},\"subtitle\":{\"tag\":\"plain_text\",\"content\":\"$s\"}$tag_json},\"body\":{\"elements\":[{\"tag\":\"markdown\",\"content\":\"$b\"},{\"tag\":\"hr\"},{\"tag\":\"markdown\",\"text_size\":\"notation\",\"content\":\"<font color='grey'>$n</font>\"}]}}}" 2>/dev/null)"
  if printf '%s' "$resp" | grep -q '"code": *0'; then
    return 0
  fi
  # 卡片失败，兜底纯文本
  local esc payload
  esc="$(json_escape "$title
$body
$note")"
  payload="{\"msg_type\":\"text\",\"content\":{\"text\":\"$esc\"}}"
  curl -s --connect-timeout 15 --max-time 30 -X POST "$FEISHU_WEBHOOK" -H "Content-Type: application/json" -d "$payload" >/dev/null 2>&1
}

login() {
  local resp
  resp=$(curl -s --connect-timeout 15 --max-time 25 -X POST "$API_BASE/login" -H "Content-Type: application/json" --data "{\"email\":\"$PANEL_EMAIL\",\"password\":\"$PANEL_PASSWORD\"}")
  echo "$resp" | sed -n 's/.*"token"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p'
}

get_mapped_id() {
  local token="$1" resp
  resp=$(curl -s --connect-timeout 15 --max-time 25 "$API_BASE/dashboard" -H "Authorization: Bearer $token")
  echo "$resp" | sed -n 's/.*"mapped_id"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p'
}

get_expires_at() {
  local token="$1" id="$2" resp
  resp=$(curl -s --connect-timeout 15 --max-time 25 "$API_BASE/instance/$id" -H "Authorization: Bearer $token")
  echo "$resp" | sed -n 's/.*"expires_at"[[:space:]]*:[[:space:]]*\([0-9]*\).*/\1/p'
}

echo "[$(date '+%F %T')] 续费提醒启动， 阈值 ${THRESHOLD_DAYS} 天"

while true; do
  token=$(login)
  if [ -z "$token" ]; then
    echo "[$(date '+%F %T')] 登录失败"
    sleep "$CHECK_INTERVAL"
    continue
  fi
  id=$(get_mapped_id "$token")
  if [ -z "$id" ]; then
    echo "[$(date '+%F %T')] 获取 mapped_id 失败"
    sleep "$CHECK_INTERVAL"
    continue
  fi
  exp=$(get_expires_at "$token" "$id")
  if [ -z "$exp" ]; then
    echo "[$(date '+%F %T')] 获取 expires_at 失败"
    sleep "$CHECK_INTERVAL"
    continue
  fi
  now=$(date +%s)
  left=$(( (exp - now) / 86400 ))
  exp_date=$(date -d "@$exp" '+%F %T' 2>/dev/null || echo "时间戳 $exp")
  if [ "$left" -le "$THRESHOLD_DAYS" ]; then
    echo "[$(date '+%F %T')] 剩余 ${left} 天， 发送续费提醒"
    exp_day=$(date -d "@$exp" '+%F' 2>/dev/null || echo "?")
    send_card orange "续费提醒" "小兔云还剩 ${left} 天到期" "**小兔云** 还剩 **${left} 天** 到期（到期 $exp_date），请尽快续费" "时间：$(date '+%F %T') · 小兔云监控" "待办" "$(metric_block "剩余天数" "${left} 天" "到期日" "$exp_day")"
  else
    echo "[$(date '+%F %T')] 剩余 ${left} 天， 无需提醒"
  fi
  sleep "$CHECK_INTERVAL"
done

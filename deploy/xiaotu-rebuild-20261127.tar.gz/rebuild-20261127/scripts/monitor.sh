#!/bin/bash
# 服务器状态检测：每 5 分钟跑一次（systemd timer），状态变化才发飞书
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/monitor_common.sh"

STATE_DIR="/root/monitor_state"
LOG_FILE="/root/monitor.log"
mkdir -p "$STATE_DIR"

log() { echo "[$(now_cn)] $*" >> "$LOG_FILE";}

# report <名字> <UP|DOWN> <详情>
# 状态变化时发飞书（先发成功再记状态，发送失败下次重试）；首次运行 DOWN 也报警
report() {
local name="$1" status="$2" detail="$3"
local state_file="$STATE_DIR/$name"
local prev="UNKNOWN"
[ -f "$state_file" ] && prev="$(cat "$state_file")"
[ "$prev" = "$status" ] && return 0
if [ "$status" = "DOWN" ]; then
if feishu_card red "服务器告警" "$name 异常" "**$name** 异常
$detail" "时间：$(now_cn) · 小兔云监控" "异常" "$(metric_block "服务器" "$name" "状态" "异常")"; then
echo "$status" > "$state_file"
log "$name: $prev -> DOWN ($detail)"
else
log "$name: DOWN alert send FAILED ($detail)"
fi
elif [ "$prev" = "UNKNOWN" ]; then
echo "$status" > "$state_file"
log "$name: init UP ($detail)"
else
if feishu_card green "服务器恢复" "$name 已恢复" "**$name** 已恢复
$detail" "时间：$(now_cn) · 小兔云监控" "已恢复" "$(metric_block "服务器" "$name" "状态" "已恢复")"; then
echo "$status" > "$state_file"
log "$name: $prev -> UP ($detail)"
else
log "$name: UP alert send FAILED ($detail)"
fi
fi
}

# --- 检测 ---
# GCP：m-ui 8443（VPN 数据面）+ nginx 443
if check_tcp 136.86.244.77 8443; then
report "GCP-VPN-8443" "UP" "m-ui 端口 8443 正常"
else
report "GCP-VPN-8443" "DOWN" "m-ui 端口 8443 连不上"
fi
if check_tcp 136.86.244.77 443; then
report "GCP-nginx-443" "UP" "nginx 端口 443 正常"
else
report "GCP-nginx-443" "DOWN" "nginx 端口 443 连不上"
fi

# 华为云新加坡：22
if check_tcp 111.91.16.60 22; then
report "华为云-新加坡" "UP" "22 端口正常"
else
report "华为云-新加坡" "DOWN" "22 端口连不上"
fi

# Azure 日本：22
if check_tcp 13.78.14.46 22; then
report "Azure-日本" "UP" "22 端口正常"
else
report "Azure-日本" "DOWN" "22 端口连不上"
fi

# Altare 新加坡 sandbox-01：SSH 端口 29459（altare-sshd，无独立 IP）
if check_tcp sg-sgp12.tryaltare.ai 29459; then
report "Altare-新加坡" "UP" "SSH 端口 29459 正常"
else
report "Altare-新加坡" "DOWN" "SSH 端口 29459 连不上"
fi

# Nodaroo 瑞典 ekko-01：ekko 公网端口 7791（容器无 SSH，测应用端口）
if check_tcp se3.nodaroo.fun 7791; then
report "Nodaroo-ekko" "UP" "ekko 端口 7791 正常"
else
report "Nodaroo-ekko" "DOWN" "ekko 端口 7791 连不上"
fi

# cloady proxy：HTTP 检测（拿到任何状态码都算活着）
if check_http "https://proxy-hqaeqnei-workspace-r6y0xr.cloady.io/"; then
report "cloady-proxy" "UP" "proxy 地址有 HTTP 响应"
else
report "cloady-proxy" "DOWN" "proxy 地址无 HTTP 响应"
fi

# hqyyk.loc.cc 主页：用户自己用，Yunamo 健康检查查的就是 @（30 天内必须指到
# 能打开、有有效证书的网站，否则域名收回）；check_http 不带 -k，证书有问题判 DOWN
if check_http "https://hqyyk.loc.cc/"; then
report "hqyyk-apex" "UP" "主页 HTTPS 正常"
else
report "hqyyk-apex" "DOWN" "主页 HTTPS 不通或证书无效"
fi

# test.hqyyk.de5.net：Cloudflare Pages 落地页（学习消息 JSON 也放这里）
if check_http "https://test.hqyyk.de5.net/"; then
report "hqyyk-test" "UP" "落地页 HTTPS 正常"
else
report "hqyyk-test" "DOWN" "落地页 HTTPS 不通或证书无效"
fi

# 本机磁盘：>80% 报警
disk_used="$(df / | awk 'NR==2 {print $5}' | tr -d '%')"
if [ -n "$disk_used" ] && [ "$disk_used" -ge 80 ]; then
report "小兔云-磁盘" "DOWN" "磁盘使用率 ${disk_used}%（超过 80%）"
else
report "小兔云-磁盘" "UP" "磁盘使用率 ${disk_used:-?}%"
fi

# 日志轮转：只留最后 500 行
if [ -f "$LOG_FILE" ]; then
tail -n 500 "$LOG_FILE" > "$LOG_FILE.tmp" && mv "$LOG_FILE.tmp" "$LOG_FILE"
fi

#!/bin/bash
# 小兔云月度维护：每月 1 号 09:00（北京时间）跑一次
# 只检查、不自动升级：补丁清单报给用户，由他定升不升（2026-11-24 用户定）
# 内容：apt 可升级包清单、磁盘/内存、失败的 unit、脚本清单漂移（与上月清单比）、
# 证书到期（3 个域名）与域名到期（2026-11-24 用户定：域名维护也放进来）、
# 每月清理：apt 缓存 + /tmp 超 7 天文件（2026-11-24 用户定：小兔云也要有清理策略）
# 汇报：发一张卡到日报机器人（炭火鸽）
# 凭据文件（密码、key 类 *.txt）不进清单、不出机器，只核对脚本与 unit 文件
# 机器是 UTC，定时器 01:00 UTC = 09:00 北京时间

BASE="${MAINT_BASE:-/root}"
UNIT_DIR="${MAINT_UNIT_DIR:-/etc/systemd/system}"
COMMON="${MAINT_COMMON:-/root/monitor_common.sh}"
TMP_DIRS="${MAINT_TMP_DIRS:-/tmp /var/tmp}"
MANIFEST="$BASE/maintenance-manifest.txt"
LOG="$BASE/maintenance-monthly.log"
# shellcheck disable=SC1090
. "$COMMON"

NL="$(printf '\nX')"; NL="${NL%X}"

# --- apt 可升级清单（只列，不升）---
apt-get update -qq 2>/dev/null
up_list="$(apt list --upgradable 2>/dev/null | grep -v '^Listing...' | cut -d/ -f1 | tr '\n' ' ')"
up_count="$(printf '%s' "$up_list" | wc -w)"
up_show="$(printf '%s' "$up_list" | cut -c1-200)"

# --- 每月清理：apt 缓存 + /tmp 超 7 天文件（清完再量磁盘）---
disk_before="$(df / | awk 'NR==2 {print $5}')"
apt-get autoclean -qq 2>/dev/null
# shellcheck disable=SC2086
find $TMP_DIRS -type f -mtime +7 -delete 2>/dev/null
# shellcheck disable=SC2086
find $TMP_DIRS -mindepth 1 -type d -empty -delete 2>/dev/null

# --- 磁盘 / 内存 ---
disk_used="$(df / | awk 'NR==2 {print $5}')"
mem_avail="$(free -m | awk '/^Mem:/ {print $7}')"

# --- 失败的 unit ---
failed="$(systemctl --failed --no-legend 2>/dev/null | awk '{print $1}' | tr '\n' ' ')"
[ -z "$failed" ] && failed="无"

# --- 证书到期（3 个域名）与域名到期 ---
cert_days() {
  local host="$1" end epoch now
  end="$(printf '' | openssl s_client -connect "$host:443" -servername "$host" 2>/dev/null | openssl x509 -noout -enddate 2>/dev/null | cut -d= -f2)"
  [ -z "$end" ] && { echo "?"; return; }
  epoch="$(date -u -d "$end" +%s 2>/dev/null)"
  [ -z "$epoch" ] && { echo "?"; return; }
  now="$(date -u +%s)"
  echo $(( (epoch - now) / 86400 ))
}
days_left() {
  local epoch now
  epoch="$(date -u -d "$1" +%s 2>/dev/null)"
  [ -z "$epoch" ] && { echo "?"; return; }
  now="$(date -u +%s)"
  echo $(( (epoch - now) / 86400 ))
}
cert_loc="$(cert_days hqyyk.loc.cc)"
cert_panel="$(cert_days panel.hqyyk.de5.net)"
cert_host="$(cert_days host.hqyyk.loc.cc)"
dom_de5="$(days_left 2027-11-02)"
cert_warn=""
[ "$cert_loc" != "?" ] && [ "$cert_loc" -lt 30 ] && cert_warn=" ⚠️ loc.cc 证书快到期"
[ "$cert_panel" != "?" ] && [ "$cert_panel" -lt 30 ] && cert_warn="${cert_warn} ⚠️ panel 证书快到期"
[ "$cert_host" != "?" ] && [ "$cert_host" -lt 30 ] && cert_warn="${cert_warn} ⚠️ host 证书快到期"

# --- 脚本清单漂移：核对 /root/*.sh 与 ExecStart 指向 /root/ 的 unit ---
tmp_manifest="$(mktemp)"
sha256sum "$BASE"/*.sh 2>/dev/null > "$tmp_manifest"
for u in "$UNIT_DIR"/*.service "$UNIT_DIR"/*.timer; do
  [ -f "$u" ] && grep -q '/root/' "$u" 2>/dev/null && sha256sum "$u" >> "$tmp_manifest"
done
sort -o "$tmp_manifest" "$tmp_manifest"
drift="无变动"
if [ -f "$MANIFEST" ]; then
  drift="$(diff "$MANIFEST" "$tmp_manifest" 2>/dev/null | sed -E 's/^< [0-9a-f]+ /删：/; s/^> [0-9a-f]+ /增\/改：/' | grep -E '^(删|增)' | cut -c1-120 | head -n 10 | tr '\n' ' ')"
  [ -z "$drift" ] && drift="无变动"
else
  drift="基线已建立（首次运行）"
fi
cp "$tmp_manifest" "$MANIFEST"
rm -f "$tmp_manifest"

# --- 发卡到日报机器人 ---
if [ "$up_count" -gt 0 ]; then
  patch_line="📦 可升级包 ${up_count} 个：${up_show}（只检查不自动升，要升在聊天里说）"
else
  patch_line="📦 可升级包 0 个，系统已是最新"
fi
body="**小兔云月度维护**${NL}${patch_line}${NL}💾 磁盘 ${disk_used:-?} · 内存可用 ${mem_avail:-?}MB${NL}🧹 清理：apt 缓存 + /tmp 超 7 天文件，磁盘 ${disk_before:-?} → ${disk_used:-?}${NL}⚠️ 失败的 unit：${failed}${NL}📋 脚本清单：${drift}${NL}🔒 证书：loc.cc ${cert_loc}天 · panel ${cert_panel}天 · host ${cert_host}天${cert_warn}${NL}🌐 域名：de5.net 还剩 ${dom_de5} 天（2027-11-02），loc.cc 到 2126 年"
feishu_card_daily purple "小兔云月度维护 · 日报" "$(today_cn)" "$body" "小兔云监控 · 每月 1 号 09:00" "日报" "$(metric_block "可升级包" "${up_count} 个" "磁盘" "${disk_used:-?}")"

# --- 日志（只留最近 50 行）---
echo "[$(now_cn)] up=$up_count disk=$disk_used mem=${mem_avail}MB failed=$failed drift=$drift" >> "$LOG"
tail -n 50 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"

#!/bin/bash
# InstaBox 保活：每 20 分钟跑一次（systemd timer），走官方 API
# 规则（与原定时保活一致）：运行中时 wake 记一次活动；接近 min(100, 单段上限-20) 分钟时
# 手动暂停再立即唤醒；Paused 时什么都不做，绝不唤醒；绝不付费/升级/绑卡。
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/monitor_common.sh"

API="https://api.instabox.sh/v1"
MID="m_agq5xg46nmqyfwqwsl7vckdmse"
KEY_FILE="/root/instabox-key"
STATE_DIR="/root/instabox"
LOG_FILE="/root/instabox-keepalive.log"
STATUS_FILE="$STATE_DIR/status"
API_BODY="/tmp/instabox_api_body.$$.json"
OP_ERR=""
OP_RETRY=""
mkdir -p "$STATE_DIR"
trap 'rm -f "$API_BODY"' EXIT

log() { echo "[$(now_cn)] $*" >> "$LOG_FILE"; }

# JSON 字段提取（无 jq，用 grep/sed）
jstr() {
  printf '%s' "$1" | grep -o "\"$2\": *\"[^\"]*\"" | head -n 1 | sed -e "s/^\"$2\": *\"//" -e 's/"$//'
}
jnum() {
  printf '%s' "$1" | grep -o "\"$2\": *[0-9]*" | head -n 1 | sed -e "s/^\"$2\": *//"
}

new_uuid() {
  if [ -r /proc/sys/kernel/random/uuid ]; then
    cat /proc/sys/kernel/random/uuid
  else
    echo "$(date +%s%N)-$$-$RANDOM"
  fi
}

# api <方法> <路径> [body] [幂等键]：响应体写 $API_BODY，标准输出打印 HTTP 状态码
api() {
  local method="$1" path="$2" body="${3:-}" idem="${4:-}"
  local args=(-s -o "$API_BODY" -w '%{http_code}' --connect-timeout 10 --max-time 60 -X "$method" "$API$path" -H "X-API-Key: $KEY")
  [ -n "$idem" ] && args+=(-H "Idempotency-Key: $idem")
  if [ -n "$body" ]; then
    args+=(-H 'Content-Type: application/json' -d "$body")
  fi
  curl "${args[@]}" 2>/dev/null || echo "000"
}

# wait_op <op_id> <最长秒数>：等操作结束，成功返回 0；失败/超时返回 1，错误码进 OP_ERR，重试秒数进 OP_RETRY
wait_op() {
  local op="$1" limit="${2:-150}" spent=0 code body opstate
  while [ "$spent" -lt "$limit" ]; do
    code="$(api GET "/operations/$op?wait=25s")"
    body="$(cat "$API_BODY" 2>/dev/null)"
    if [ "$code" != "200" ]; then
      log "wait_op $op: GET failed http=$code"
      sleep 5; spent=$((spent + 30)); continue
    fi
    opstate="$(jstr "$body" state)"
    if [ "$opstate" = "succeeded" ]; then return 0; fi
    if [ "$opstate" = "failed" ]; then
      OP_ERR="$(jstr "$body" code)"
      OP_RETRY="$(jnum "$body" retryAfterSeconds)"
      return 1
    fi
    spent=$((spent + 25))
  done
  log "wait_op $op: timeout after ${limit}s"
  return 1
}

# 同类提醒只发一次（flag 文件存在则跳过）；恢复时由调用方清 flag
# alert_once <flag> <template> <标题> <副标题> <正文> <备注> <标签> [指标块JSON]
alert_once() {
  local flag="$STATE_DIR/alert_$1"
  [ -f "$flag" ] && return 0
  if feishu_card "$2" "$3" "$4" "$5" "$6" "$7" "$8"; then touch "$flag"; fi
}
clear_alert() { rm -f "$STATE_DIR/alert_$1"; }

# 连续失败计数：fail_count <名> inc|clear，打印当前次数
fail_count() {
  local f="$STATE_DIR/fail_$1" n=0
  [ -f "$f" ] && n="$(cat "$f")"
  if [ "$2" = "inc" ]; then n=$((n + 1)); else n=0; fi
  echo "$n" > "$f"
  echo "$n"
}

[ -r "$KEY_FILE" ] || { log "ERROR: key file $KEY_FILE missing"; exit 1; }
KEY="$(cat "$KEY_FILE")"
[ -n "$KEY" ] || { log "ERROR: key file empty"; exit 1; }

code="$(api GET "/machines/$MID")"
body="$(cat "$API_BODY" 2>/dev/null)"
if [ "$code" != "200" ]; then
  n="$(fail_count api inc)"
  log "GET machine failed http=$code (consecutive $n)"
  if [ "$n" -ge 3 ]; then
    alert_once api_fail red "InstaBox 告警" "API 连续检查失败" "**InstaBox** API 连续 3 次检查失败（HTTP $code），保活暂停检查，请看一下" "时间：$(now_cn) · 小兔云监控" "异常" "$(metric_block "连续失败" "3 次" "状态" "API 异常")"
  fi
  exit 0
fi
fail_count api clear >/dev/null
clear_alert api_fail

state="$(jstr "$body" state)"
maxrun="$(jnum "$body" maxRunMinutes)"
runstarted="$(jstr "$body" runStartedAt)"
cooldown="$(jstr "$body" cooldownUntil)"
now_epoch="$(date -u +%s)"

# 写状态文件给早报用：state|maxRunMinutes|runStartedAt|cooldownUntil|检查时间戳
printf '%s|%s|%s|%s|%s\n' "$state" "$maxrun" "$runstarted" "$cooldown" "$now_epoch" > "$STATUS_FILE"

case "$state" in
running)
  age_min=-1
  if [ -n "$runstarted" ] && [ "$runstarted" != "null" ]; then
    start_epoch="$(date -u -d "$runstarted" +%s 2>/dev/null)"
    [ -n "$start_epoch" ] && age_min=$(( (now_epoch - start_epoch) / 60 ))
  fi
  limit="${maxrun:-120}"
  threshold=$((limit - 20))
  [ "$threshold" -gt 100 ] && threshold=100
  [ "$threshold" -lt 5 ] && threshold=5
  if [ "$age_min" -ge 0 ] && [ "$age_min" -ge "$threshold" ]; then
    log "segment age ${age_min}min >= threshold ${threshold}min, cycling..."
    idem="$(new_uuid)"
    code="$(api POST "/machines/$MID/suspend" '{}' "$idem")"
    body="$(cat "$API_BODY" 2>/dev/null)"
    if [ "$code" != "202" ]; then
      err="$(jstr "$body" code)"
      if [ "$code" = "409" ] && [ "$err" = "operation_conflict" ]; then
        log "suspend skipped: another cycle in progress"
        exit 0
      fi
      log "suspend failed http=$code code=$err"
      alert_once cycle_fail red "InstaBox 告警" "暂停失败" "**InstaBox** 暂停失败（HTTP $code，$err），本段已跑 ${age_min} 分钟，接近上限，请看一下" "时间：$(now_cn) · 小兔云监控" "异常" "$(metric_block "本段已跑" "${age_min} 分钟" "状态" "暂停失败")"
      exit 0
    fi
    op="$(jstr "$body" id)"
    if ! wait_op "$op" 150; then
      log "suspend op $op failed err=$OP_ERR"
      alert_once cycle_fail red "InstaBox 告警" "暂停操作失败" "**InstaBox** 暂停操作失败（$OP_ERR），本段已跑 ${age_min} 分钟，请看一下" "时间：$(now_cn) · 小兔云监控" "异常" "$(metric_block "本段已跑" "${age_min} 分钟" "状态" "暂停失败")"
      exit 0
    fi
    idem="$(new_uuid)"
    code="$(api POST "/machines/$MID/resume" '{}' "$idem")"
    body="$(cat "$API_BODY" 2>/dev/null)"
    if [ "$code" != "202" ]; then
      err="$(jstr "$body" code)"
      retry="$(jnum "$body" retryAfterSeconds)"
      log "resume failed http=$code code=$err retryAfter=${retry}"
      if [ "$code" = "409" ] && [ "$err" = "operation_conflict" ]; then
        log "resume skipped: another cycle in progress"
        exit 0
      fi
      if [ "$err" = "machine_cooldown" ]; then
        alert_once cooldown red "InstaBox 告警" "机器进冷却" "**InstaBox** 机器进冷却了，唤醒被拒，约 ${retry:-?} 秒后可恢复，冷却期间不唤醒" "时间：$(now_cn) · 小兔云监控" "冷却" "$(metric_block "冷却等待" "${retry:-?} 秒" "状态" "冷却中")"
      else
        alert_once cycle_fail red "InstaBox 告警" "唤醒失败" "**InstaBox** 唤醒失败（HTTP $code，$err），机器已暂停，请看一下" "时间：$(now_cn) · 小兔云监控" "异常" "$(metric_block "本段已跑" "${age_min} 分钟" "状态" "唤醒失败")"
      fi
      exit 0
    fi
    op="$(jstr "$body" id)"
    if ! wait_op "$op" 180; then
      log "resume op $op failed err=$OP_ERR retryAfter=$OP_RETRY"
      if [ "$OP_ERR" = "machine_cooldown" ]; then
        alert_once cooldown red "InstaBox 告警" "机器进冷却" "**InstaBox** 机器进冷却了，唤醒被拒，约 ${OP_RETRY:-?} 秒后可恢复，冷却期间不唤醒" "时间：$(now_cn) · 小兔云监控" "冷却" "$(metric_block "冷却等待" "${OP_RETRY:-?} 秒" "状态" "冷却中")"
      else
        alert_once cycle_fail red "InstaBox 告警" "唤醒操作失败" "**InstaBox** 唤醒操作失败（$OP_ERR），机器已暂停，请看一下" "时间：$(now_cn) · 小兔云监控" "异常" "$(metric_block "本段已跑" "${age_min} 分钟" "状态" "唤醒失败")"
      fi
      exit 0
    fi
    log "cycle ok: segment restarted (was ${age_min}min)"
    clear_alert cycle_fail; clear_alert cooldown
  else
    code="$(api POST "/machines/$MID/wake" '{}')"
    if [ "$code" = "200" ]; then
      log "wake ok (age ${age_min}min / limit ${limit}min)"
      fail_count wake clear >/dev/null
    else
      body="$(cat "$API_BODY" 2>/dev/null)"
      err="$(jstr "$body" code)"
      if [ "$code" = "409" ] && [ "$err" = "machine_not_running" ]; then
        log "wake skipped: machine paused between check and wake"
        exit 0
      fi
      n="$(fail_count wake inc)"
      log "wake failed http=$code code=$err (consecutive $n)"
      if [ "$n" -ge 3 ]; then
        alert_once wake_fail red "InstaBox 告警" "活动 ping 连续失败" "**InstaBox** 活动 ping 连续 3 次失败（HTTP $code，$err），机器可能空闲暂停，请看一下" "时间：$(now_cn) · 小兔云监控" "异常" "$(metric_block "连续失败" "3 次" "状态" "ping 失败")"
      fi
    fi
  fi
  ;;
suspended)
  if [ -n "$cooldown" ] && [ "$cooldown" != "null" ]; then
    cd_epoch="$(date -u -d "$cooldown" +%s 2>/dev/null)"
    if [ -n "$cd_epoch" ] && [ "$cd_epoch" -gt "$now_epoch" ]; then
      left_min=$(( (cd_epoch - now_epoch) / 60 ))
      log "suspended, in cooldown (${left_min}min left), do nothing"
      alert_once cooldown red "InstaBox 告警" "机器进冷却" "**InstaBox** 机器被强制暂停进冷却，约 ${left_min} 分钟后可恢复，冷却期间不唤醒" "时间：$(now_cn) · 小兔云监控" "冷却" "$(metric_block "剩余冷却" "${left_min} 分钟" "状态" "冷却中")"
      exit 0
    fi
  fi
  log "suspended, do nothing (user decides)"
  clear_alert cooldown
  ;;
stopped)
  log "stopped, do nothing (user decides)"
  alert_once stopped orange "InstaBox 待确认" "机器已停止" "**InstaBox** 机器已停止，需要你决定是否启动（保活不会自动启动）" "时间：$(now_cn) · 小兔云监控" "待确认" "$(metric_block "机器" "dashboard" "状态" "已停止")"
  ;;
creating|starting|stopping|suspending|resuming|deleting)
  log "transitional state $state, wait for next cycle"
  ;;
*)
  log "unexpected state: $state"
  alert_once badstate red "InstaBox 告警" "状态异常" "**InstaBox** 机器状态异常：$state，请看一下" "时间：$(now_cn) · 小兔云监控" "异常" "$(metric_block "机器状态" "$state")"
  ;;
esac

# 日志轮转：只留最后 500 行
if [ -f "$LOG_FILE" ]; then
  tail -n 500 "$LOG_FILE" > "$LOG_FILE.tmp" && mv "$LOG_FILE.tmp" "$LOG_FILE"
fi

#!/usr/bin/env bash
# Azure 预算检查（每天 07:30 北京时间运行一次，在早间简报之前）
# 查本月已花金额，超预算 50/80/100% 时发飞书卡片（每月每档只提醒一次）；
# 写状态文件 /root/azure-budget/status 供简报读取真实花费。
#
# 凭证文件 /root/azure-budget/credentials（600 权限，部署时由浏览器任务写入，不进任何文件与汇报）：
#   TENANT_ID=...        Azure AD 租户 ID
#   CLIENT_ID=...        应用注册的客户端 ID
#   CLIENT_SECRET=...    客户端密钥
#   SUBSCRIPTION_ID=...  Azure for Students 订阅 ID
# 服务主体只需订阅上的 Cost Management Reader（只读）角色。
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/monitor_common.sh"

CRED_FILE="/root/azure-budget/credentials"
STATE_DIR="/root/azure-budget"
STATUS_FILE="$STATE_DIR/status"
LOG_FILE="$STATE_DIR/budget.log"
BUDGET_LIMIT_USD=10
CNY_PER_USD=7.2   # 仅当 API 返回人民币时用于估算百分比（近似值，告警用，非精确账单）

log() {
  echo "[$(now_cn)] $1" >> "$LOG_FILE"
  if [ "$(wc -l < "$LOG_FILE")" -gt 500 ]; then
    tail -n 500 "$LOG_FILE" > "$LOG_FILE.tmp" && mv "$LOG_FILE.tmp" "$LOG_FILE"
  fi
}

mkdir -p "$STATE_DIR"
if [ ! -f "$CRED_FILE" ]; then
  log "credentials 文件缺失，退出"
  exit 1
fi
# shellcheck disable=SC1090
. "$CRED_FILE"
for v in TENANT_ID CLIENT_ID CLIENT_SECRET SUBSCRIPTION_ID; do
  if [ -z "${!v:-}" ]; then
    log "$v 缺失，退出"
    exit 1
  fi
done

# 1. 取 ARM token（client credentials 模式）
token_resp="$(curl -s -m 30 --connect-timeout 10 -X POST "https://login.microsoftonline.com/${TENANT_ID}/oauth2/v2.0/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=client_credentials&client_id=${CLIENT_ID}&client_secret=${CLIENT_SECRET}&scope=https%3A%2F%2Fmanagement.azure.com%2F.default" 2>/dev/null)"
token="$(printf '%s' "$token_resp" | sed -n 's/.*"access_token"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')"
if [ -z "$token" ]; then
  log "取 token 失败"
  exit 1
fi

# 2. 查本月实际花费（Cost Management query，MonthToDate；解析失败重试 3 次）
# 2026-11-17 00:15 首次手动跑曾解析失败一次、重试成功，故加重试。
query='{"type":"ActualCost","timeframe":"MonthToDate","dataset":{"granularity":"None","aggregation":{"totalCost":{"name":"PreTaxCost","function":"Sum"}}}}'
spend=""
currency=""
attempt=0
while [ "$attempt" -lt 3 ]; do
  attempt=$((attempt + 1))
  cost_resp="$(curl -s -m 30 --connect-timeout 10 -X POST "https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/providers/Microsoft.CostManagement/query?api-version=2023-11-01" \
    -H "Authorization: Bearer ${token}" -H "Content-Type: application/json" -d "$query" 2>/dev/null)"
  compact="$(printf '%s' "$cost_resp" | tr -d ' \n\r\t')"
  # 响应形如 {"properties":{"rows":[[0.06,"USD"]],"columns":[...]}}
  spend="$(printf '%s' "$compact" | grep -o '"rows":\[\[[0-9.]*' | sed 's/.*"rows":\[\[//')"
  currency="$(printf '%s' "$compact" | grep -o '"rows":\[\[[0-9.]*,"[A-Z]*"' | sed 's/.*,"//; s/"//')"
  if [ -n "$spend" ] && [ -n "$currency" ]; then
    break
  fi
  spend=""
  currency=""
  log "花费查询第 ${attempt} 次失败（响应无法解析）"
  if [ "$attempt" -lt 3 ]; then
    sleep 10
  fi
done
if [ -z "$spend" ] || [ -z "$currency" ]; then
  log "花费查询失败（3 次重试均无法解析响应）"
  exit 1
fi

# 3. 算百分比（预算 $10/月；人民币按固定汇率估算）
if [ "$currency" = "USD" ]; then
  limit="$BUDGET_LIMIT_USD"
elif [ "$currency" = "CNY" ]; then
  limit="$(awk -v u="$BUDGET_LIMIT_USD" -v r="$CNY_PER_USD" 'BEGIN{printf "%.2f", u*r}')"
else
  # 未知货币：只记状态，不告警
  printf '%s|%s|?|%s' "$spend" "$currency" "$(date -u +%s)" > "$STATUS_FILE"
  log "本月已用 ${spend} ${currency}（未知货币，不计算百分比）"
  exit 0
fi
pct="$(awk -v s="$spend" -v l="$limit" 'BEGIN{printf "%.1f", s/l*100}')"
printf '%s|%s|%s|%s' "$spend" "$currency" "$pct" "$(date -u +%s)" > "$STATUS_FILE"
log "本月已用 ${spend} ${currency}（${pct}% / 预算 ${limit} ${currency}）"

# 4. 阈值告警（每月每档只发一次；100% 用红色，其余橙色）
month="$(date -u -d '+8 hours' '+%Y-%m')"
for level in 50 80 100; do
  threshold="$(awk -v l="$limit" -v p="$level" 'BEGIN{printf "%.4f", l*p/100}')"
  if awk -v s="$spend" -v t="$threshold" 'BEGIN{exit (s>=t)?0:1}'; then
    flag="$STATE_DIR/alerted_${level}"
    if [ ! -f "$flag" ] || [ "$(cat "$flag")" != "$month" ]; then
      echo "$month" > "$flag"
      if [ "$level" = "100" ]; then
        tpl="red"
      else
        tpl="orange"
      fi
      feishu_card "$tpl" "预算提醒" "Azure 本月已用 ${pct}%（${spend} ${currency}）" "**Azure for Students** 本月已花费 **${spend} ${currency}**，达到月预算 **${pct}%**（预算 ${limit} ${currency}）。" "时间：$(now_cn) · 小兔云监控" "待办" "$(metric_block "本月已用" "${spend} ${currency}" "预算占比" "${pct}%")"
      log "已发 ${level}% 阈值提醒"
    fi
  fi
done

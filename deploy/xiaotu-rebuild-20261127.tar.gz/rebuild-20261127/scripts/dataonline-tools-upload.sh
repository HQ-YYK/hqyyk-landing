#!/usr/bin/env bash
# DataOnline /tools/ 安装包自动上传（小兔云中转）
#
# 背景：浏览器传 20MB+ 安装包 5 次全断（2026-11-23/24），改走脚本：
# 小兔云逐个从官网下载安装包，验大小 + SHA256，再 FTP 传到 DataOnline。
# FTP 账号 tools@host.hqyyk.loc.cc 只限 public_html/tools/files/ 目录，
# 密码存在 /root/dataonline-ftp-pass（600），不在本脚本里。
# 传完请删除该 FTP 账号并删掉密码文件。
#
# 断点续传：远端已有且大小一致的文件自动跳过；下载支持 curl -C - 续传。
# 重跑安全：可反复执行，只补传缺失/大小不对的文件。
#
# 用法（小兔云上）：
#   nohup /root/dataonline-tools-upload.sh >/root/dataonline-tools-upload.log 2>&1 &
#   tail -f /root/dataonline-tools-upload.log
# 完成后发一张飞书卡（炭火鸡）：全成功绿色，有失败红色并列出失败文件。
#
# 部署：小兔云 /root/dataonline-tools-upload.sh（本地 workspace 这份只是编辑草稿）

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/monitor_common.sh"

FTP_USER="tools@host.hqyyk.loc.cc"
PASS_FILE="/root/dataonline-ftp-pass"
WORK_DIR="/root/tools-upload"
STATUS_FILE="/root/tools-upload/status"

# 文件清单：文件名|下载地址|字节数|SHA256|备用下载地址（可空）
# 来源：tools/README.md（2026-11-23 核实）；Tailscale 在 pkgs，其余在 GitHub releases
read -r -d '' FILE_LIST <<'LIST'
tailscale-setup-1.104.7-amd64.msi|https://pkgs.tailscale.com/stable/tailscale-setup-1.104.7-amd64.msi|38775808|676b5b32fdd1aeaee90d8e8f38e222635b216fbdfbf877bf01cb1d7cda330ec5|
Tailscale-1.104.7-macos.pkg|https://pkgs.tailscale.com/stable/Tailscale-1.104.7-macos.pkg|22369022|0ecab60e098d31f9cbd334867474293dc08978154665da75c3f3fe1f8215d6e7|
tailscale-android-universal-1.104.7.apk|https://pkgs.tailscale.com/stable/tailscale-android-universal-1.104.7.apk|105727207|5a620e118c36a203bdde43ddd93ef4122ce2d8ab2f7ad59ec30b6bbf391e01d9|
rustdesk-1.5.3-x86_64.exe|https://github.com/rustdesk/rustdesk/releases/download/1.5.3/rustdesk-1.5.3-x86_64.exe|26233712|523ba0efbf62a21739961b62c7daaffb44d3da86139c546b364fd4e1333ed249|
rustdesk-1.5.3-aarch64.dmg|https://github.com/rustdesk/rustdesk/releases/download/1.5.3/rustdesk-1.5.3-aarch64.dmg|31464911|e6d30fa1633d772c48935907c208ca4e555a856fb2038af3aaa87a327c29360b|
rustdesk-1.5.3-x86_64.dmg|https://github.com/rustdesk/rustdesk/releases/download/1.5.3/rustdesk-1.5.3-x86_64.dmg|37715587|74d06e6b2e273a128e8d36313e30d47db2063f453a4235ed4d9e5cdfdf9be538|
rustdesk-1.5.3-aarch64-signed.apk|https://github.com/rustdesk/rustdesk/releases/download/1.5.3/rustdesk-1.5.3-aarch64-signed.apk|29282490|6b3aca1a7e68c3f80e5abe7ec3bea3e5ff445a03cf77131ff79a1ee4270288ff|
Clash.Verge_2.5.10_x64-setup.exe|https://github.com/clash-verge-rev/clash-verge-rev/releases/download/v2.5.10/Clash.Verge_2.5.10_x64-setup.exe|60045702|929da9303b643b80ce309ab29f618e37a5562f515d1fa55ebf5b86c822504450|
Clash.Verge_2.5.10_aarch64.dmg|https://github.com/clash-verge-rev/clash-verge-rev/releases/download/v2.5.10/Clash.Verge_2.5.10_aarch64.dmg|80769307|40d4a7da4543d75f573a5cfcc31543b0b4bf7e02caa122a9ca50654859585839|
Clash.Verge_2.5.10_x64.dmg|https://github.com/clash-verge-rev/clash-verge-rev/releases/download/v2.5.10/Clash.Verge_2.5.10_x64.dmg|86532364|b1d6938680f3e411b5961e56591faaa92c95e9676f54ebfdfa98b7eab374023e|
FlClash-0.9.4-windows-amd64-setup.exe|https://github.com/chen08209/FlClash/releases/download/v0.9.4/FlClash-0.9.4-windows-amd64-setup.exe|43132829|77f84fdf24ccb1499e6c0275b713c3a81031f157496e1c5305366184da1ac68a|
FlClash-0.9.4-macos-arm64.dmg|https://github.com/chen08209/FlClash/releases/download/v0.9.4/FlClash-0.9.4-macos-arm64.dmg|55625224|db0784e7e5a69fc93da85accf4d8d80812e7e014f2082609da395ba6124195c5|
FlClash-0.9.4-macos-amd64.dmg|https://github.com/chen08209/FlClash/releases/download/v0.9.4/FlClash-0.9.4-macos-amd64.dmg|59502497|481f742112572a6488a5ec40ddd071283dc59eb4d91da1e399be25acaf79e8eb|
FlClash-0.9.4-android-arm64-v8a.apk|https://github.com/chen08209/FlClash/releases/download/v0.9.4/FlClash-0.9.4-android-arm64-v8a.apk|60863675|86fb6f66b5f4d36a3423adeadca625b147da0e782400b6af69aafe58c603a947|https://github.com/chen08209/FlClash/releases/download/v0.9.4/FlClash-0.9.4-android-arm64.apk
cmfa-2.11.37-meta-arm64-v8a-release.apk|https://github.com/MetaCubeX/ClashMetaForAndroid/releases/download/v2.11.37/cmfa-2.11.37-meta-arm64-v8a-release.apk|47672833|84be4f17a166a966828f1674a5e9a063211e855c6d066d660c72fc7489b053a4|
LIST

log() { echo "[$(date '+%F %T')] $*"; }

mkdir -p "$WORK_DIR"

if [ ! -f "$PASS_FILE" ]; then
  log "ERROR: 密码文件不存在：$PASS_FILE（先写好再跑）"
  exit 1
fi
FTP_PASS="$(cat "$PASS_FILE")"
if [ -z "$FTP_PASS" ]; then
  log "ERROR: 密码文件为空"
  exit 1
fi

# 选一个能连上的 FTP 主机（ftp 子域名未在 Yunamo 建记录，大概率不通；先试面板域名，再试 IP）
FTP_HOST=""
for h in sv66.dataonline.vn 103.137.185.66; do
  if curl -s --user "$FTP_USER:$FTP_PASS" "ftp://$h/" --max-time 20 -o /dev/null; then
    FTP_HOST="$h"
    log "FTP 主机：$FTP_HOST（登录成功）"
    break
  else
    log "FTP 主机 $h 连不上或登录失败，试下一个"
  fi
done
if [ -z "$FTP_HOST" ]; then
  log "ERROR: 两个 FTP 主机都连不上"
  feishu_card "red" "/tools/ 安装包上传失败" "host.hqyyk.loc.cc" "FTP 两个主机都连不上（sv66.dataonline.vn、103.137.185.66），请检查 FTP 服务或账号。" "日志：/root/dataonline-tools-upload.log" "告警" ""
  exit 1
fi

# 查远端文件大小（FTP HEAD 取 Content-Length；不存在返回空）
# 注意：上传刚完成时立即查可能读到空值（2026-11-24 首轮 2 个文件因此误判失败，
# 实际文件已传好；重跑校验即通过），所以空值时重试 3 次、每次等 3 秒。
remote_size() {
  local i out
  for i in 1 2 3; do
    out="$(curl -sI --user "$FTP_USER:$FTP_PASS" "ftp://$FTP_HOST/$1" --max-time 30 \
      | grep -i '^Content-Length:' | awk '{print $2}' | tr -d '\r' | head -n1)"
    if [ -n "$out" ]; then
      echo "$out"
      return 0
    fi
    sleep 3
  done
  echo ""
}

total=0
ok=0
skipped=0
failed=""

echo "$FILE_LIST" | while IFS='|' read -r name url size sha alt; do
  [ -z "$name" ] && continue
  total=$((total + 1))
  local_file="$WORK_DIR/$name"

  # 远端已有且大小一致：跳过
  rs="$(remote_size "$name")"
  if [ -n "$rs" ] && [ "$rs" = "$size" ]; then
    log "SKIP $name（远端已有，$size 字节）"
    skipped=$((skipped + 1))
    echo "SKIPPED $name" >> "$STATUS_FILE.tmp"
    continue
  fi

  # 下载（断点续传 + 重试 3 次；主地址失败则试备用地址）
  log "DOWNLOAD $name"
  if ! curl -fSL --retry 3 --retry-delay 5 --connect-timeout 30 -C - -o "$local_file" "$url"; then
    if [ -n "$alt" ]; then
      log "主地址失败，试备用地址：$alt"
      rm -f "$local_file"
      curl -fSL --retry 3 --retry-delay 5 --connect-timeout 30 -o "$local_file" "$alt" || true
    fi
  fi
  if [ ! -f "$local_file" ]; then
    log "FAIL $name：下载失败"
    failed="$failed $name(下载失败)"
    echo "FAILED $name download" >> "$STATUS_FILE.tmp"
    continue
  fi

  # 验大小 + SHA256
  ls_size="$(stat -c%s "$local_file" 2>/dev/null)"
  if [ "$ls_size" != "$size" ]; then
    log "FAIL $name：大小不对，本地 $ls_size，应为 $size"
    rm -f "$local_file"
    failed="$failed $name(大小不对)"
    echo "FAILED $name size" >> "$STATUS_FILE.tmp"
    continue
  fi
  ls_sha="$(sha256sum "$local_file" | awk '{print $1}')"
  if [ "$ls_sha" != "$sha" ]; then
    log "FAIL $name：SHA256 不对"
    rm -f "$local_file"
    failed="$failed $name(SHA256不对)"
    echo "FAILED $name sha" >> "$STATUS_FILE.tmp"
    continue
  fi

  # FTP 上传（被动模式；账号根目录就是 files/，直接传到 /）
  log "UPLOAD $name（$size 字节）"
  if ! curl -f -T "$local_file" --user "$FTP_USER:$FTP_PASS" "ftp://$FTP_HOST/$name" --ftp-pasv --connect-timeout 30; then
    log "FAIL $name：FTP 上传失败"
    failed="$failed $name(上传失败)"
    echo "FAILED $name upload" >> "$STATUS_FILE.tmp"
    continue
  fi

  # 验远端大小
  rs="$(remote_size "$name")"
  if [ "$rs" != "$size" ]; then
    log "FAIL $name：远端大小不对（$rs，应为 $size）"
    failed="$failed $name(远端大小不对)"
    echo "FAILED $name remote-size" >> "$STATUS_FILE.tmp"
    continue
  fi

  rm -f "$local_file"
  ok=$((ok + 1))
  log "OK $name"
  echo "OK $name" >> "$STATUS_FILE.tmp"
done

# while 在管道里跑，计数器在子 shell 里丢了；改从状态文件汇总
mv -f "$STATUS_FILE.tmp" "$STATUS_FILE" 2>/dev/null || touch "$STATUS_FILE"
total="$(echo "$FILE_LIST" | grep -c .)"
ok="$(grep -c '^OK ' "$STATUS_FILE")"
skipped="$(grep -c '^SKIPPED ' "$STATUS_FILE")"
failed_list="$(grep '^FAILED ' "$STATUS_FILE" | sed 's/^FAILED //' | tr '\n' ' ')"
fail_count="$(grep -c '^FAILED ' "$STATUS_FILE")"

log "完成：新传 $ok 个，跳过 $skipped 个，失败 $fail_count 个（共 $total 个）"
metric="$(metric_block "新传成功" "$ok 个" "失败" "$fail_count 个")"
if [ "$fail_count" -eq 0 ]; then
  feishu_card "green" "/tools/ 安装包上传完成" "host.hqyyk.loc.cc" "15 个安装包已全部就位（新传 $ok 个，之前已有的 $skipped 个），/tools/ 下载链接可用。传完记得删掉临时 FTP 账号 tools@host.hqyyk.loc.cc 和小兔云上的密码文件。" "日志：/root/dataonline-tools-upload.log" "成功" "$metric"
else
  feishu_card "red" "/tools/ 安装包上传未完成" "host.hqyyk.loc.cc" "新传 $ok 个，跳过 $skipped 个，失败 $fail_count 个：$failed_list。重跑脚本可只补传失败的。" "日志：/root/dataonline-tools-upload.log" "告警" "$metric"
fi

#!/usr/bin/env bash
# 定时提醒（卡片版）：每天检查 reminders.txt，到日期的提醒发飞书卡片，只发一次
# 部署时占位符会被换成真实 webhook（不进任何文件与汇报）
FEISHU_WEBHOOK="__FEISHU_WEBHOOK__"
REMINDER_FILE="/root/reminders.txt"
CHECK_INTERVAL=86400
STATE_DIR="/root/remind_state"
mkdir -p "$STATE_DIR"

# JSON 转义（无 python3，用 sed）
json_escape() {
  printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' -e ':a;N;$!ba;s/\n/\\n/g'
}

# 指标块：metric_block <标签1> <值1> [标签2] [值2]（浅灰底 column_set，大数字 + 小灰字）
metric_block() {
  local l1="$1" v1="$2" l2="${3:-}" v2="${4:-}"
  local c1 c2 cols
  c1="{\"tag\":\"column\",\"width\":\"weighted\",\"weight\":1,\"background_style\":\"grey-50\",\"elements\":[{\"tag\":\"markdown\",\"text_size\":\"notation\",\"content\":\"<font color='grey'>$(json_escape "$l1")</font>\"},{\"tag\":\"markdown\",\"text_size\":\"heading\",\"content\":\"**$(json_escape "$v1")**\"}]}"
  cols="$c1"
  if [ -n "$l2" ]; then
    c2="{\"tag\":\"column\",\"width\":\"weighted\",\"weight\":1,\"background_style\":\"grey-50\",\"elements\":[{\"tag\":\"markdown\",\"text_size\":\"notation\",\"content\":\"<font color='grey'>$(json_escape "$l2")</font>\"},{\"tag\":\"markdown\",\"text_size\":\"heading\",\"content\":\"**$(json_escape "$v2")**\"}]}"
    cols="$c1,$c2"
  fi
  printf '{"tag":"column_set","background_style":"grey-50","flex_mode":"stretch","columns":[%s]}' "$cols"
}

# 发飞书卡片（Card JSON 2.0；2.0 不支持 note 标签，底部备注用灰色 markdown）
# send_card <template> <标题> <副标题> <正文markdown> <底部备注> [状态标签] [指标块JSON]
send_card() {
  local template="$1" title="$2" subtitle="$3" body="$4" note="$5" tag="${6:-}" metric="${7:-}"
  local t s b n resp tag_json="" metric_json=""
  case "$template" in
    blue|green|red|orange|purple) ;;
    *) template="blue" ;;
  esac
  t="$(json_escape "$title")"
  s="$(json_escape "$subtitle")"
  b="$(json_escape "$body")"
  n="$(json_escape "$note")"
  if [ -n "$tag" ]; then
    tag_json=",\"text_tag_list\":[{\"tag\":\"text_tag\",\"text\":{\"tag\":\"plain_text\",\"content\":\"$(json_escape "$tag")\"},\"color\":\"$template\"}]"
  fi
  if [ -n "$metric" ]; then
    metric_json=",${metric}"
  fi
  resp="$(curl -s --connect-timeout 15 --max-time 30 -X POST "$FEISHU_WEBHOOK" -H "Content-Type: application/json" -d "{\"msg_type\":\"interactive\",\"card\":{\"schema\":\"2.0\",\"header\":{\"template\":\"$template\",\"title\":{\"tag\":\"plain_text\",\"content\":\"$t\"},\"subtitle\":{\"tag\":\"plain_text\",\"content\":\"$s\"}$tag_json},\"body\":{\"vertical_spacing\":\"16px\",\"padding\":\"16px 20px\",\"elements\":[{\"tag\":\"markdown\",\"content\":\"$b\"}$metric_json,{\"tag\":\"hr\"},{\"tag\":\"markdown\",\"text_size\":\"notation\",\"content\":\"<font color='grey'>$n</font>\"}]}}}" 2>/dev/null)"
  if printf '%s' "$resp" | grep -q '"code": *0'; then
    return 0
  fi
  # 新版卡片失败，兜底极简卡（去掉指标块与容器间距）
  resp="$(curl -s --connect-timeout 15 --max-time 30 -X POST "$FEISHU_WEBHOOK" -H "Content-Type: application/json" -d "{\"msg_type\":\"interactive\",\"card\":{\"schema\":\"2.0\",\"header\":{\"template\":\"$template\",\"title\":{\"tag\":\"plain_text\",\"content\":\"$t\"},\"subtitle\":{\"tag\":\"plain_text\",\"content\":\"$s\"}$tag_json},\"body\":{\"elements\":[{\"tag\":\"markdown\",\"content\":\"$b\"},{\"tag\":\"hr\"},{\"tag\":\"markdown\",\"text_size\":\"notation\",\"content\":\"<font color='grey'>$n</font>\"}]}}}" 2>/dev/null)"
  if printf '%s' "$resp" | grep -q '"code": *0'; then
    return 0
  fi
  # 卡片失败，兜底纯文本
  local esc payload
  esc="$(json_escape "$title
$body
$note")"
  payload="{\"msg_type\":\"text\",\"content\":{\"text\":\"$esc\"}}"
  curl -s --connect-timeout 15 --max-time 30 -X POST "$FEISHU_WEBHOOK" -H "Content-Type: application/json" -d "$payload" >/dev/null 2>&1
}

to_epoch() {
  local d="$1"
  if date -d "$d" +%s >/dev/null 2>&1; then
    date -d "$d" +%s
  else
    date -D '%Y-%m-%d' -d "$d" +%s
  fi
}

echo "[$(date '+%F %T')] 定时提醒启动，配置文件 $REMINDER_FILE"

while true; do
  if [ ! -f "$REMINDER_FILE" ]; then
    echo "[$(date '+%F %T')] 未找到 $REMINDER_FILE，请先创建"
    sleep "$CHECK_INTERVAL"
    continue
  fi
  today=$(date +%s)
  while IFS='|' read -r date content; do
    [ -z "$date" ] && continue
    case "$date" in \#*) continue;; esac
    [ -z "$content" ] && continue
    content=$(echo "$content" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')
    d_epoch=$(to_epoch "$date")
    [ -z "$d_epoch" ] && { echo "[$(date '+%F %T')] 日期格式错误: $date"; continue; }
    if [ "$today" -ge "$d_epoch" ]; then
      mark="$STATE_DIR/$(echo "$date|$content" | tr ' ' '_')"
      if [ ! -f "$mark" ]; then
        touch "$mark"
        echo "[$(date '+%F %T')] 触发提醒: $date - $content"
        send_card blue "提醒" "$date" "**$content**" "时间：$(date '+%F %T') · 小兔云监控" "提醒" "$(metric_block "提醒日期" "$date")"
      fi
    fi
  done < "$REMINDER_FILE"
  sleep "$CHECK_INTERVAL"
done

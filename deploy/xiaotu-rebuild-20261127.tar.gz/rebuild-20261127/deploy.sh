#!/bin/bash
# 小兔云监控重建部署脚本（2026-11-27 容器重建后恢复）
# 用法：在小兔云上以 root 运行：bash deploy.sh
# 做：校验 md5 → 装脚本到 /root/ → 装 units 到 /etc/systemd/system/ → 建状态目录与空凭证文件 → daemon-reload → 语法检查
# 不做：不启用定时器（等密钥补齐后另行启用并验证）；不碰 argosbx；不写任何真实密钥（占位符保持原样）
set -u
PKG="$(cd "$(dirname "$0")" && pwd)"
fail() { echo "STEP-FAILED: $*" >&2; exit 1; }

[ "$(id -u)" = 0 ] || fail "need root"

echo "== STEP 1: 校验文件 =="
cd "$PKG" || fail "cd pkg"
md5sum -c MANIFEST.md5 || fail "md5 mismatch"
echo "OK"

echo "== STEP 2: 安装脚本 =="
cp scripts/*.sh /root/ || fail "copy scripts"
chmod +x /root/*.sh
echo "OK"

echo "== STEP 3: 安装 systemd 单元 =="
cp units/*.service units/*.timer /etc/systemd/system/ || fail "copy units"
systemctl daemon-reload || fail "daemon-reload"
echo "OK"

echo "== STEP 4: 建状态目录与空凭证文件 =="
mkdir -p /root/monitor_state /root/instabox /root/briefing-news /root/remind_state /root/relay-checkin /root/azure-budget /root/tools-upload
for f in /root/feishu-daily-webhook.txt /root/instabox-key /root/obsidian-key /root/relay-checkin/credentials /root/azure-budget/credentials; do
  if [ ! -f "$f" ]; then touch "$f"; chmod 600 "$f"; echo "created empty $f"; else echo "exists (kept) $f"; fi
done
echo "OK"

echo "== STEP 5: 语法检查 =="
for s in /root/briefing.sh /root/monitor.sh /root/monitor_common.sh /root/watchdog.sh /root/learning.sh /root/feed.sh /root/relay-checkin.sh /root/instabox-keepalive.sh /root/sweep-notify.sh /root/maintenance-monthly.sh /root/remind.sh /root/renew_remind.sh /root/dataonline-renewal-watch.sh /root/mui-update-notify.sh /root/monthly-cleanup-check.sh /root/azure-budget.sh /root/dataonline-tools-upload.sh; do
  bash -n "$s" || fail "syntax $s"
done
echo "OK"

echo "== ALL DONE (定时器未启用，等密钥补齐后启用并验证) =="
ls -l /root/*.sh | awk '{print $5, $9}'
echo "--- units installed ---"
systemctl list-unit-files --no-pager | grep -E 'briefing|monitor|watchdog|learning|feed|relay|instabox|sweep|maintenance|remind|renew|dataonline|azure|mui|monthly' || true
